export const ObjectRoadmap = {
    lightBg: false,
    primary: true,
    imgStart: '',
    lightTopLine: true,
    lightTextDesc: true,
    buttonLabel: "Connect MetaMask to start",
    description: "Placeholder Roadmap",
    headline: "Placeholder Roadmap",
    lightText: true,
    topLine: "Blockgangsters.io",
    img: require('../../images/logo.svg').default,
    alt: 'Image',
    start: '',

};
