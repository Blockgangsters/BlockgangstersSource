export const dataSet = [
  {
    name: 'Q3 \'21',
    Team: 0,
    Bootstrap: 0,
    Rewards: 0,
  },
  {
    name: 'Q4 \'21',
    Team: 36,
    Bootstrap: 150,
    Rewards: 75,
  },
  {
    name: 'Q1 \'22',
    Team: 72,
    Bootstrap: 150,
    Rewards: 150,
  },
  {
      name: 'Q2 \'22',
      Team: 108,
      Bootstrap: 150,
      Rewards: 225,
    },
    {
      name: 'Q3 \'22',
      Team: 144,
      Bootstrap: 150,
      Rewards: 300,
    },
    {
      name: 'Q4 \'22',
      Team: 180,
      Bootstrap: 150,
      Rewards: 375,
    },
    {
      name: 'Q1 \'23',
      Team: 180,
      Bootstrap: 150,
      Rewards: 450,
    },
    {
      name: 'Q2 \'23',
      Team: 180,
      Bootstrap: 150,
      Rewards: 525,
    },
    {
        name: 'Q3 \'23',
        Team: 180,
        Bootstrap: 150,
        Rewards: 600,
      },
      {
        name: 'Q4 \'23',
        Team: 180,
        Bootstrap: 150,
        Rewards: 675
      }
];

export const data = [
  { name: 'Marketing', value: 20 },
  { name: 'Team', value: 30 },
  { name: 'Oracle', value: 10},
  { name: 'Audits', value: 20 },
  { name: 'Long term treasury', value: 20 },
];