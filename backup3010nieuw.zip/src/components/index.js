export {default as Navbar} from './Navbar/Navbar';
export {default as InfoSection} from './InfoSection/InfoSection';
export {default as Footer} from './Footer/Footer'; 
export {default as Gamebar} from './Gamebar/Gamebar';